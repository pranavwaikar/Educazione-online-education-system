<?php
	include_once 'includes/dbh_inc.php';
	session_start();
	
	echo '<link rel="stylesheet" href="assets/css/bootstrap.min.css" />';
?>	


 <span>
			        
						<?php
						//again check if user is logged in.
							if(isset($_SESSION['u_id']))
							{
								$u_id=$_SESSION['u_id'];
							}
							else
							{
								header("Location: index.php");
								exit();
							}
						//running query now
							$sql="select c_name,c_since,c_till,c_catagory,points from courses c,user_result r where(r.u_id='$u_id' and r.c_id=c.c_id);";
							$resultx=mysqli_query($conn , $sql);
							$result_check=mysqli_num_rows($resultx);
					
							if($result_check <= 0)
							{
								echo '<h4>No results !</h4>';
							}
							else
							{
								//if result is returned then print it.
								//printing table head
								echo '    <h4>Result of courses</h4>
											<div class="table-responsive">
												<table class="table">
													<thead>
														<tr>
															
															<th>Name</th>
															<th>Since</th>
															<th>Till</th>
															<th>Catagory</th>
															<th>Points</th>
														</tr>
													</thead>
													<tbody>';
								//printing results row by row
								while($row = mysqli_fetch_array($resultx, MYSQLI_ASSOC))
								{
								echo '<tr>
		                        <td class="text-center">';
								echo $row['c_name'];
								echo '</td><td>';
								echo $row['c_since'];
								echo '</td><td>';
								echo $row['c_till'];
								echo '</td><td>';
								echo $row['c_catagory'];
								echo '</td><td>';
								echo $row['points'];
								echo '</tr>';
								}
								echo '</tbody>
										</table>
										</div>';
							
							}
							
						?>