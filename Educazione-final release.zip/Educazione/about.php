<?php 
	include_once 'header.php';
?>

 <!--main content-->
<!--Main content-->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Main image on page -->
	<h1>Educazione</h1>
    <section id="slider">
		<a href="#"><img src="assets/img/ppr.jpg" height="360" width="960" alt="About Educazione"></a>
	</section>
  
    <div id="homepage">
      
	<p>Educazione is a platform for online education. We personally select the courses so that 
	  the user should get only the best courses.</p>
	<p>If you are good at something then join us on this platform and share your knowledge
		and become instructor.</p>
	<p> For becoming instructor, Please use <a href="assets/new_course_template.zip">THIS template.</a></p>
	<p>After creating template, send the template along with your name,email-id,experience,occupation to contactus@educazione.com </p>
	<p>Educazione is created by <a href="https://www.facebook.com/pranav.waikar">Pranav Waikar</a>,<a href="https://www.facebook.com/viratpratik">Pratik Deshumukh</a>,<a href="https://www.facebook.com/rohan.patel.33449">Rohan Patel.</a></p>
	 
    </div>
	</div>
</div>




<?php
	include_once 'footer.php';
?>