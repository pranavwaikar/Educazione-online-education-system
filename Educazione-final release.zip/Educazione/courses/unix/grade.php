<?php
	include_once '../../includes/dbh_inc.php';
	session_start();
?>
<link rel="stylesheet" href="bootstrap.min.css" />

	<div id="page-wrap">

		<h1>Test result</h1>
		
        <?php
		//#############Course id goes here #################
		$c_id=2;
		$u_id=$_SESSION['u_id'];
            
            $answer1 = $_POST['question-1-answers'];
            $answer2 = $_POST['question-2-answers'];
            $answer3 = $_POST['question-3-answers'];
            $answer4 = $_POST['question-4-answers'];
            $answer5 = $_POST['question-5-answers'];
        
            $totalCorrect = 0;
            
            if ($answer1 == "B") { $totalCorrect++; }
            if ($answer2 == "A") { $totalCorrect++; }
            if ($answer3 == "C") { $totalCorrect++; }
            if ($answer4 == "D") { $totalCorrect++; }
            if ($answer5 == "A") { $totalCorrect++; }
            
            echo "<div id='results'>Your score =$totalCorrect</div>";
            
			//check if previous result of exam exists
			$sql="select * from user_result where u_id='$u_id' and c_id='$c_id';";
			$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
			$result_check=mysqli_num_rows($result);
			//if result exists then update the new result
			if($result_check >0)
			{			
			$sql="update user_result SET points='$totalCorrect' where u_id='$u_id' and c_id='$c_id';";
			$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);

			}
			else
			{
			
			//insert record into user_result table
			$sql="insert into user_result (u_id,c_id,points) values ('$u_id','$c_id','$totalCorrect');";
			$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
			
			//Increase the RANK by 1
			$sql="select * from users where u_id='$u_id';";
			$resultx=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
			$row = mysqli_fetch_array($resultx, MYSQLI_ASSOC);
			
			$u_rank=$row['u_rank']+1;
			echo '<h4>RANK=';
			echo $u_rank;
			echo '</h4>';
			$sql="update users SET u_rank='$u_rank' where u_id='$u_id';";
			$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);

			
			}
			
			//remove from enrolled table
			$sql="DELETE FROM enrolled_for WHERE u_id='$u_id' and c_id='$c_id';";
			$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
			
        ?>
	<h4>You completed the course successfully!<h4>
	</div>
	
		<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
	</script>
	<script type="text/javascript">
	var pageTracker = _gat._getTracker("UA-68528-29");
	pageTracker._initData();
	pageTracker._trackPageview();
	</script>


