<h4>Linux architecture</h4>
<p>	The linux architecture is like the onion ring structure.<br>
	There is famous saying that- in unix and onion as you go deeper it leads to tears!.
</p>
<img src="arch.jpg" height="300" width="300"></img>
<p>	Hardware:-- This refers to the hardware layer of any computer system.<br>
Kernel:--  This sits on top of Hardware and it interacts with the hardware. 
		This is the core of the Operating system and acts as an interface between the user activities and the hardware.
		It provides the base functionality of the OS. The major functionality of the kernel includes process management,
		memory management, thread management, scheduling, I/O management and power management.<br>
Shell:-- This is an interface between the user and the kernel. 
		It interprets the commands from a user and executes the resulting request.
		Post processing the commands kernel returns back the instructions to the shell.<br>
There are various types of command line shells in Unix: Bourne Shell, C Shell, Korn Shell, Bourne Again Shell (bash).<br>
User:-- communicates with Shell through Commands.
</p>

<p>Follow along with this guided tutorial video.<br>
</p>
<iframe width="560" height="315" src="https://www.youtube.com/embed/O0P0-AwPueQ" frameborder="0" allowfullscreen></iframe>
