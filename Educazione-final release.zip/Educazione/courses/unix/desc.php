<?php
	include_once '../../includes/dbh_inc.php';
	session_start();
	echo '<link rel="stylesheet" href="bootstrap.min.css" />';
	//##################assign your c_id here###############################
	$c_id=2;
	$u_id=$_SESSION['u_id'];
	
	$sql="select c_name,c_since,c_till,c_catagory,c_status from courses c where c_id='$c_id';";
	$resultx=mysqli_query($conn , $sql);
	$result_check=mysqli_num_rows($resultx);
	
		//if result is returned then print it.
								//printing table head
								echo '    <h4>Course Details</h4>
											<div class="table-responsive">
												<table class="table">
													<thead>
														<tr>
															
															<th>Name</th>
															<th>Since</th>
															<th>Till</th>
															<th>Catagory</th>
															
														</tr>
													</thead>
													<tbody>';
								//printing results row by row
								while($row = mysqli_fetch_array($resultx, MYSQLI_ASSOC))
								{
								echo '<tr>
		                        <td>';
								echo $row['c_name'];
								echo '</td><td>';
								echo $row['c_since'];
								echo '</td><td>';
								echo $row['c_till'];
								echo '</td><td>';
								echo $row['c_catagory'];
								echo '</td>
										</tr>';
								}
								echo '</tbody>
										</table>
										</div>';
								echo '<form action="enrollme.php" method="post" id="user_enroll_form">
										<input type="hidden" name="u_id" value="' .$u_id . '" />
										<input type="hidden" name="c_id" value="' .$c_id . '" />
										</form>					
										<button class="btn btn-default" form="user_enroll_form" name="submit" value="Submit">Enroll NOW</button>';
?>


<!--################Write your course description here###############################-->
<!-- -->
<h4>Course offerings:-</h4>
<p> 1)The basic intoduction to UNIX.<br>
    2)The new LINUX era.<br>
	3)The unix architecture.<br>
	4)The unix processes.<br>
	5)The test of 5 questions for 5 points.<br>
</p>
<h4>Course Instructor:-</h4>
<p> Rohan patel. Student at SITS,pune.
</p>

	