<h4>What is LINUX?</h4>
<p>
UNIX is a Unix-like computer operating system 
assembled under the model of free and open-source software development and distribution. 
The defining component of Linux is the Linux kernel,
 an operating system kernel first released on September 17, 1991 by Linus Torvalds.
 The Free Software Foundation uses the name GNU/Linux to describe the operating system, 
 which has led to some controversy.
</p>
h4>How linux is created?</h4>
<p>
In 1991, while attending the University of Helsinki, 
Torvalds became curious about operating systems and frustrated by the licensing of MINIX, 
which at the time limited it to educational use only.
 He began to work on his own operating system kernel, which eventually became the Linux kernel.

Torvalds began the development of the Linux kernel on MINIX
 and applications written for MINIX were also used on Linux. 
 Later, Linux matured and further Linux kernel development took place on Linux systems.
 GNU applications also replaced all MINIX components, 
 because it was advantageous to use the freely available code 
 from the GNU Project with the fledgling operating system; 
 code licensed under the GNU GPL can be reused in other computer programs 
 as long as they also are released under the same or a compatible license.
 Torvalds initiated a switch from his original license, 
 which prohibited commercial redistribution, to the GNU GPL.
 Developers worked to integrate GNU components with the Linux kernel, 
 making a fully functional and free operating system.
</p>
	
<p>Follow along with this guided tutorial video.<br>
	See you in next class!!!
</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/zA3vmx0GaO8" frameborder="0" allowfullscreen></iframe>
