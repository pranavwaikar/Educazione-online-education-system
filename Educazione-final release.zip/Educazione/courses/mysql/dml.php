<h4>DDL Commands</h4>
<p>	This stands for the Data Manipulation Language.
    DML is used to describe the data manipulation.<br>
	Data Manipulation Language (DML) statements 
	or commands are used for managing data within tables
</p>
	<ul>
	<li>Insert :The insert statement is used to add new row to a table.</li><br>
	<code>INSERT INTO table_name VALUES (value_1, ... value_n);</code><br><br>
	<li>UPDATE :The update statement is used to change values that are already in a table.</li>
	<code>UPDATE table_name SET attr> = expre WHERE cond;</code><br><br>
	<li>DELETE :The delete statement deletes row(s) from a table.</li>
	<code>DELETE FROM table_name WHERE condit;</code><br><br>
	<li>SELECT :The SELECT statement is used to form queries for 
	extracting information out of the database.</li>
	<code>SELECT attrib, ….., attrib n FROM table_name;</code><br><br>
	</ul>
	
	These are the basic queries for the DML.
<p>

<p>Follow along with this guided tutorial video.<br>
</p>
<iframe width="560" height="315" src="https://www.youtube.com/embed/pyG9Nj2HDxI" frameborder="0" allowfullscreen></iframe>