<h2> Welcome to MYSQL course.</h2>

<h4>What is mysql? </h4>
<p> MYSQL is a database. This is relational database.<br>
    In relational databases you can just store data in form of relations between tables.<br>
	SQL stands for Structured Query Language which is just to interact with the database.
	The database offers you quick easy access to store and retrieve data across all platforms.
</p>
<h4>How to install the database software</h4>
<p>Follow along with this guided tutorial video.<br>
	See you in next class!!!
</p>
<iframe width="560" height="315" src="https://www.youtube.com/embed/9CwSmdWqI7g" frameborder="0" allowfullscreen></iframe>
