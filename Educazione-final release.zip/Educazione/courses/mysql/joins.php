<h4>SQL JOIN</h4>
<p>A JOIN clause is used to combine rows from two or more tables, based on 
a related column between them.</p>

<h2>Different Types of SQL JOINs</h2>
<p>Here are the different types of the JOINs in SQL:</p>
<ul>
  <li><b>(INNER) JOIN</b>: Returns records that have matching values in both tables</li>
  <li><b>LEFT (OUTER) JOIN</b>: Return all records from the left table, and the matched records from the right table</li>
  <li><b>RIGHT (OUTER) JOIN</b>: Return all records from the right table, and the matched 
  records from the left table</li>
  <li><b>FULL (OUTER) JOIN</b>: Return all records when there is a match in either left 
  or right table</li>
</ul>


<p>
<img alt="SQL INNER JOIN" height="145" src="img_innerjoin.gif" width="200">&nbsp;
<img alt="SQL LEFT JOIN" height="145" src="img_leftjoin.gif" width="200">&nbsp;
<img alt="SQL RIGHT JOIN" height="145" src="img_rightjoin.gif" width="200">&nbsp;
<img alt="SQL FULL OUTER JOIN" height="145" src="img_fulljoin.gif" width="200">
</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/KTvYHEntvn8" frameborder="0" allowfullscreen></iframe>
