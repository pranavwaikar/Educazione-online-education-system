<h4>Applications of IBM WATSON</h4>

<h2>1. Healthcare</h2><p>The medical field is the sector 
that is likely being impacted the most by Watson. 
For starters, Watson has taken residence at three of the top cancers hospitals 
in the US -- Memorial Sloan Kettering Cancer Center, University of Texas MD Anderson Cancer Center, 
and the Mayo Clinic -- where it helps with cancer research and patient care. In terms of cancer research, 
Watson is speeding up DNA analysis in cancer patients to help make their treatment more effective. </p> 

<h2>2. Finance</h2>
<p>In the financial sector,
 Watson use is typically geared toward its question and answer capabilities.
 By not only answering questions, but also analyzing them as well, 
 Watson can help give financial guidance and help manage financial risk.</p>

<h2>3. Legal</h2>
<p>When it comes to the law, most of us likely have more questions 
than answers on any topic. However, startups such as ROSS Intelligence Inc.
 are using Watson to make it easier to get answers to your burning legal questions.
 </p><p>According to ROSS's website, users can ask questions in plain English and
 the app uses NLP to understand the questions and then sifts through the entirety of a
 database to return a cited answer with relevant legislation. ROSS also monitors potential 
 changes to relevant laws and alerts you when changes occur.</p><p>Singapore's Inland Revenue
 Authority is another organization using Watson to help answer legal questions, deploying Watson
 to field questions about tax.</p>

<p> this video tells about uses and creating watson apps for your problems.
<iframe width="560" height="315" src="https://www.youtube.com/embed/PwG8aTjOo94" frameborder="0" allowfullscreen></iframe>