<h4>How IBM watson works?</h4>
<p>	
Watson parses questions into different keywords and sentence fragments 
in order to find statistically related phrases.
 Watson's main innovation was not in the creation of a new algorithm
 for this operation but rather its ability to quickly execute hundreds of proven
 language analysis algorithms simultaneously. The more algorithms that 
 find the same answer independently the more likely Watson is to be correct.
 Once Watson has a small number of potential solutions,
 it is able to check against its database to ascertain whether the solution makes sense or not.
 
 Watson's basic working principle is to parse keywords in a clue while searching for related terms as responses.
 This gives Watson some advantages and disadvantages compared with human Jeopardy! players.
 Watson has deficiencies in understanding the contexts of the clues.
 As a result, human players usually generate responses faster than Watson,
 especially to short clues. Watson's programming prevents it from using the
 popular tactic of buzzing before it is sure of its response.
 Watson has consistently better reaction time on the buzzer once it has generated a response, 
 and is immune to human players' psychological tactics, such as jumping between categories on every clue.
</p>


<p>Follow along with this guided tutorial video.<br>
</p>
<iframe width="560" height="315" src="https://www.youtube.com/embed/_Xcmh1LQB9I" frameborder="0" allowfullscreen></iframe>

