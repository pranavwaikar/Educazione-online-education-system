<h4>What is Cognitive computing?</h4>
<p>	

Cognitive computing is the simulation of human thought processes in a computerized model. Cognitive computing involves self-learning systems that use data mining, pattern recognition and natural language processing to mimic the way the human brain works. The goal of cognitive computing is to create automated IT systems that are capable of solving problems without requiring human assistance.

Cognitive computing systems use machine learning algorithms. Such systems continually acquire knowledge from the data fed into them by mining data for information. The systems refine the way they look for patterns and as well as the way they process data so they become capable of anticipating new problems and modeling possible solutions.

Cognitive computing is used in numerous artificial intelligence (AI) applications, including expert systems, natural language programming, neural networks, robotics and virtual reality. The term cognitive computing is closely associated with IBM’s cognitive computer system, Watson.

</p>

<p>See Dr. John Kelly's presentation on the future of cognitive computing:.<br>
	See you in next class!!!
</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/q7qElhGv7uY" frameborder="0" allowfullscreen></iframe>

