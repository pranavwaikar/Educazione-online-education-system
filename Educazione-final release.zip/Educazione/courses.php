 <?php 
	include_once 'header.php';
 ?>
 

<div class="row" style="background-color:#ffffff;">
  <div id="container" class="row">
    <!-- Main image on page -->

    
	<div id="content" style="width: 300px;">
          <aside id="left_column">
      <h2 class="title">Courses</h2>
      <nav>
        <ul class="list-group">
          <li><a href="active.php" target="iframe_a" class="list-group-item">Active courses</a></li>
          <li><a href="inactive.php" target="iframe_a" class="list-group-item">Inactive courses</a></li>
	      <li><a href="by_instructor.php" target="iframe_a" class="list-group-item">By instructors</a></li>
		  <li><a href="by_catagory.php" target="iframe_a" class="list-group-item">By Catagory</a></li>
		</ul>
      </nav>
    </div>

	<div style="height:59px;"></div>

	<div class="col-md- col-md-offset-1">
	
	<iframe src="courses_load.php" name="iframe_a" style="border:none;" height="600" width="650"></iframe>
			        

				   </div>
   </div>
</div>
	
 <?php 
	include_once 'footer.php';
 ?>