<?php
	include_once 'header.php';
?>


<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Main image on page -->
	<form action="includes/login_inc.php" method="post" id="user_log_in_form">
	<div class="form-group label-floating">
		<label class="control-label">Enter E-mail ID</label>
		<input type="email" class="form-control" name="email">
	</div>
	<div class="form-group label-floating">
		<label class="control-label">Enter Password</label>
		<input type="password" class="form-control" name="password">
	</div>
	<button class="btn btn-default" form="user_log_in_form"  name="submit" value="Submit">Log-in</button>
	</form>
	
	<a href="signup.php" class="btn btn-default">Register</a>
</div> 
   
   </div>
</div>

<?php
	include_once 'footer.php';
?>